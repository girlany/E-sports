-- AlterTable
ALTER TABLE "Jogador" ADD COLUMN     "id_time" INTEGER;

-- AddForeignKey
ALTER TABLE "Jogador" ADD CONSTRAINT "Jogador_id_time_fkey" FOREIGN KEY ("id_time") REFERENCES "Todo"("id") ON DELETE SET NULL ON UPDATE CASCADE;
