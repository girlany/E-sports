const express = require("express");

//const allTodos = [{ nome: "br", status: false }];
const jogadorRoutes = express.Router();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

    jogadorRoutes.post("/jogador", async (request, response) => {
      const { nome } = request.body;
      const jogador = await prisma.jogador.create({
        data: {
          nome,
          idade,
          time_id,
          id_time,
         
        },
      });
    
      return response.status(201).json(jogador);
    });


    jogadorRoutes.get("/jogador", async (request, response) => {
         const jogador = await prisma.jogador.findMany();
         return response.status(200).json(jogador);
      });
      
      // UPDATE

      jogadorRoutes.put("/jogador", async (request, response) => {
  const { time_id, id_time, idade, nome, id } = request.body;

  if (!id) {
    return response.status(400).json("Id is mandatory");
  }


  const todoAlreadyExist = await prisma.jogador.findUnique({ where: { id } });

  if (!todoAlreadyExist) {
    return response.status(404).json("Todo not exist");
  }

  const jogador = await prisma.jogador.update({
    where: {
      id,
    },
    data: {
      nome,
      idade,
      id_time,
      time_id,
    },
  });

  return response.status(200).json(jogador);
});


// DELETE
jogadorRoutes.delete("/jogador/:id", async (request, response) => {
  const { id } = request.params;

  const intId = parseInt(id);

  if (!intId) {
    return response.status(400).json("Id is mandatory");
  }

  const jogadorAlreadyExist = await prisma.jogador.findUnique({
    where: { id: intId },
  });

  if (!jogadorAlreadyExist) {
    return response.status(404).json("Todo not exist");
  }

  await prisma.jogador.delete({ where: { id: intId } });

  return response.status(200).send();
  
});


    module.exports = jogadorRoutes;
