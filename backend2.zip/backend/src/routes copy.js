const express = require("express");

const allTodos = [{ nome: "bruno", status: false }];
const todosRoutes = express.Router();

// Create
todosRoutes.post("/todos", async (request, response) => {
    const { name } = request.body;
    allTodos.push({name, status: false});
    return response.status(201).json(allTodos);
 
    
    });

    module.exports = todosRoutes;
  
  // R
  todosRoutes.get("/todos", async (request, response) => {
    const todos = await prisma.todo.findMany();
    return response.status(200).json(todos);
  });
  // U